﻿EnesMem portable build
=======================
Fast launch (recommended): EnesMem\EnesMem.exe
Single-file alternative:   EnesMem-1.1.0-win64-onefile.exe

Admin: recommended; required for protected/elevated targets.
Data: settings are stored per Windows user; UIV snapshots use %LOCALAPPDATA%\EnesMem\tmp.

Build details
-------------
App version: 1.1.0 (native core: 0.2.0)
Portable folder: 93,2 MB
Single-file exe: 48,5 MB
EnesMem.exe SHA-256: 5b63a8dfd1b437ce081d0c6da664c329a2ee8ea9719d84f609902963eebe1aa4
Single-file SHA-256: 09b2339c0e44dd69f26d31c09ede888418025e93961f81c32ede552002e63ff7

The portable folder is portable: do not move EnesMem.exe away from _internal.
The single-file exe needs no companion files and is intended for GitHub download.
