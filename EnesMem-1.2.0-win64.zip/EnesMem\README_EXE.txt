﻿EnesMem portable build
=======================
Fast launch (recommended): EnesMem\EnesMem.exe
Single-file alternative:   ..\EnesMem-1.2.0-win64-onefile.exe

Admin: recommended; required for protected/elevated targets.
Data: settings are stored per Windows user; UIV snapshots use %LOCALAPPDATA%\EnesMem\tmp.

Build details
-------------
App version: 1.2.0 (native core: 0.2.0)
Portable folder: 93,2 MB
Single-file exe: 48,5 MB
EnesMem.exe SHA-256: 6f4d897d9a9936737b2fd05b104a912b44710e5d9f579583d0ecf025d9446001
Single-file SHA-256: 9edaf783bbbff12bb490f8ec74ea835ce18cd35572e4dc6d100f46f21beab562

The portable folder is portable: do not move EnesMem.exe away from _internal.
The single-file exe needs no companion files and is intended for GitHub download.
