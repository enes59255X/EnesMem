﻿EnesMem portable build
=======================
Fast launch (recommended): EnesMem\EnesMem.exe
Single-file alternative:   ..\EnesMem-1.2.0-win64-onefile.exe

Admin: recommended; required for protected/elevated targets.
Data: settings are stored per Windows user; UIV snapshots use %LOCALAPPDATA%\EnesMem\tmp.

Build details
-------------
App version: 1.2.0 (native core: 0.2.0)
Portable folder: 93,2 MB
Single-file exe: 48,5 MB
EnesMem.exe SHA-256: fa8f247b334249f201dc4a535a48c23b1c6c56f8aa9218506f8356405db59efc
Single-file SHA-256: 165439abbdf2714c30f212df4eb3eed0bf75547fe87781b11d4099128bc0b32b

The portable folder is portable: do not move EnesMem.exe away from _internal.
The single-file exe needs no companion files and is intended for GitHub download.
